<?php
$link = mysqli_connect("localhost", "root", "999");
mysqli_select_db($link, "notes");
?>