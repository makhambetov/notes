


var del = $(".delete_note");
del.hide();

var ajax = new XMLHttpRequest();


function showDel(){
	del.fadeToggle();
}

function removeNote(noteId, elementIndex){
	ajax.open("GET", "remove_note.php?id="+noteId, false)
	ajax.send(null);
	$(".note-wrapper:eq("+elementIndex+")").slideUp("fast");
	console.log($(".note-wrapper"));
}

function openNote(noteId){
	ajax.open("GET", "open_note.php?id="+noteId, false)
	ajax.send(null);
}