<div style="text-align: center;">
	<h1 >Welcome to the <span style="color: #1B96FE">NOTES</span></h1>
<a style="width: 250px; height: 40px" href="login.php" class="btn btn-primary">Log in</a>
<br><br>
<a style="width: 250px; height: 40px" href="signup.php" class="btn btn-success">Sign Up</a>
</div>
